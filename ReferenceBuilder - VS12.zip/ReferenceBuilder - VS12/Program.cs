﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Collections;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace ProjectBuilder
{
    public delegate void UpdatedEventHandler(Dictionary<string, Project> dctProjects, DCT_Type enmProject);

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

    sealed class Data
    {
        public static event UpdatedEventHandler DataChanged;

        public static string s_RefPath = @"F:\SVN\App\AutomatedBuild\CreateNantScript";
        public static string s_ProjectPath = @"F:\SVN\App\v1.1\{0}\Client\App\{1}";
        public static string s_RootPath = @"F:\SVN\App\v1.1\";
        static bool bBinSubFolders = false;
        private static ArrayList s_ignoreFolders;
        private static int s_iDepth = 0;
        static Dictionary<string, Project> s_Projects;
        static Dictionary<string, Project> s_Projects_Common;
        static Dictionary<string, Project> s_Projects_TCommon;
        static Dictionary<string, Project> s_Projects_Gateway;

        static Dictionary<string, Project> s_VBPs;
        static Dictionary<string, Project> s_References;
        static Dictionary<string, Project> s_Merged;
        static Dictionary<string, Project> s_Orphan;
        static SortedDictionary<string, Reference> s_AllReferences;

        public static void exportToXML()
        {
            string sPath = @"C:\Temp\References.xml";

            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<references/>");

            XmlNode root = doc.DocumentElement;
            XmlAttribute newAttr = null;
            XmlElement elem = null;
            XmlElement elem2 = null;
            XmlElement elem3 = null;
            XmlElement elem4 = null;

            foreach (KeyValuePair<string, Reference> kvp in s_AllReferences)
            {
                elem = doc.CreateElement(kvp.Key);
                //elem.InnerText = "a";
                newAttr = doc.CreateAttribute("guid");
                newAttr.Value = kvp.Value.GUID;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("referenced_by");
                newAttr.Value = kvp.Value.ReferecedBy.Count.ToString();
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("description");
                newAttr.Value = kvp.Value.Project.Description;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("BinPath");
                newAttr.Value = kvp.Value.Project.BinPath;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("EXEName");
                newAttr.Value = kvp.Value.Project.EXEName;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("SourcePath");
                newAttr.Value = kvp.Value.Project.SourcePath;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("VBP");
                newAttr.Value = kvp.Value.Project.VBP;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("Version");
                newAttr.Value = kvp.Value.Project.Version;
                elem.Attributes.Append(newAttr);

                //elem4 = doc.CreateElement("ControlUsed");

                //foreach (KeyValuePair<string, Project> _prj in kvp.Value.Project.ControlUsed)
                //{
                //    elem2 = doc.CreateElement(_prj.Key);

                //    newAttr = doc.CreateAttribute("EXEName");
                //    newAttr.Value = _prj.Value.EXEName;
                //    elem2.Attributes.Append(newAttr);

                //    newAttr = doc.CreateAttribute("description");
                //    newAttr.Value = _prj.Value.Description;
                //    elem2.Attributes.Append(newAttr);

                //    newAttr = doc.CreateAttribute("GUID");
                //    newAttr.Value = _prj.Value.GUID;
                //    elem2.Attributes.Append(newAttr);

                //    newAttr = doc.CreateAttribute("Version");
                //    newAttr.Value = _prj.Value.Version;
                //    elem2.Attributes.Append(newAttr);

                //    elem4.AppendChild(elem2);
                //}

                elem4 = doc.CreateElement("referenced_by");

                foreach (KeyValuePair<string, Project> _prj in kvp.Value.ReferecedBy)
                {
                    elem2 = doc.CreateElement(_prj.Key);

                    newAttr = doc.CreateAttribute("guid");
                    newAttr.Value = _prj.Value.GUID;
                    elem2.Attributes.Append(newAttr);
                    
                    newAttr = doc.CreateAttribute("description");
                    newAttr.Value = _prj.Value.Description;
                    elem2.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("BinPath");
                    newAttr.Value = _prj.Value.BinPath;
                    elem2.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("EXEName");
                    newAttr.Value = _prj.Value.EXEName;
                    elem2.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("SourcePath");
                    newAttr.Value = _prj.Value.SourcePath;
                    elem2.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("VBP");
                    newAttr.Value = _prj.Value.VBP;
                    elem2.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("Version");
                    newAttr.Value = _prj.Value.Version;
                    elem2.Attributes.Append(newAttr);

                    elem3 = doc.CreateElement("references");
                    foreach (KeyValuePair<string, Project> _prj2 in _prj.Value.References)
                    {
                        //elem3 = doc.CreateElement(_prj2.Key);
                        //elem2.AppendChild(elem3);
                        elem3.AppendChild(doc.CreateElement(_prj2.Key));
                    }
                    elem2.AppendChild(elem3);
                    //elem.AppendChild(elem2);
                    elem4.AppendChild(elem2);
                }

                elem.AppendChild(elem4);
                root.AppendChild(elem);
            }

            doc.Save(sPath);

        }


        public static void exportToXML2()
        {
            string sPath = @"C:\Temp\Projects.xml";

            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<projects/>");

            XmlNode root = doc.DocumentElement;
            XmlAttribute newAttr = null;
            XmlElement elem = null;
            XmlElement elem2 = null;
            XmlElement elem3 = null;
            XmlElement elem4 = null;

            foreach (KeyValuePair<string, Project> kvp in s_Merged)
            {

                elem = doc.CreateElement(kvp.Key);

                newAttr = doc.CreateAttribute("guid");
                newAttr.Value = kvp.Value.GUID;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("description");
                newAttr.Value = kvp.Value.Description;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("BinPath");
                newAttr.Value = kvp.Value.BinPath;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("EXEName");
                newAttr.Value = kvp.Value.EXEName;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("SourcePath");
                newAttr.Value = kvp.Value.SourcePath;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("VBP");
                newAttr.Value = kvp.Value.VBP;
                elem.Attributes.Append(newAttr);

                newAttr = doc.CreateAttribute("Version");
                newAttr.Value = kvp.Value.Version;
                elem.Attributes.Append(newAttr);

                elem2 = doc.CreateElement("references");
                foreach (KeyValuePair<string, Project> _prj2 in kvp.Value.References)
                {
                    elem3 = doc.CreateElement(_prj2.Key);

                    newAttr = doc.CreateAttribute("EXEName");
                    newAttr.Value = _prj2.Value.EXEName;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("description");
                    newAttr.Value = _prj2.Value.Description;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("GUID");
                    newAttr.Value = _prj2.Value.GUID;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("Version");
                    newAttr.Value = _prj2.Value.Version;
                    elem3.Attributes.Append(newAttr);

                    elem2.AppendChild(elem3);
                }

                elem.AppendChild(elem2);


                elem2 = doc.CreateElement("ControlUsed");

                foreach (KeyValuePair<string, Project> _prj in kvp.Value.ControlUsed)
                {
                    elem3 = doc.CreateElement(_prj.Key);

                    newAttr = doc.CreateAttribute("EXEName");
                    newAttr.Value = _prj.Value.EXEName;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("description");
                    newAttr.Value = _prj.Value.Description;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("GUID");
                    newAttr.Value = _prj.Value.GUID;
                    elem3.Attributes.Append(newAttr);

                    newAttr = doc.CreateAttribute("Version");
                    newAttr.Value = _prj.Value.Version;
                    elem3.Attributes.Append(newAttr);

                    elem2.AppendChild(elem3);
                }
                elem.AppendChild(elem2);

                root.AppendChild(elem);
            }

            doc.Save(sPath);

        }

        public static SortedDictionary<string, Reference> AllReferences
        {
            get { return Data.s_AllReferences; }
            set { Data.s_AllReferences = value; }
        }
        static bool s_includeOrphans = false;

        public static bool bin_SearchSubFolders
        {
            get { return bBinSubFolders; }
            set { bBinSubFolders = value; }
        }

        public static ArrayList ignoreFolders
        {
            get { return Data.s_ignoreFolders; }
            set { Data.s_ignoreFolders = value; }
        }

        public Data()
        {

        }

        public static string GetGuid(string fileName)
        {
            string guid = "";
            try
            {
                TLI.TLIApplication tliApp = new TLI.TLIApplication();
                TLI.TypeLibInfo tli = tliApp.TypeLibInfoFromFile(fileName);

                guid = tli.GUID;

                tli = null;
                tliApp = null;
            }
            catch (Exception)
            {
                guid = "{ERROR}";
            }

            return guid;

        }

        public static IEnumerable<System.IO.FileInfo> GetFiles(string path)
        {
            if (!System.IO.Directory.Exists(path))
                throw new System.IO.DirectoryNotFoundException();

            string[] fileNames = null;
            List<System.IO.FileInfo> files = new List<System.IO.FileInfo>();

            System.IO.SearchOption search = System.IO.SearchOption.AllDirectories;
            if (!Data.bBinSubFolders)
                {search = System.IO.SearchOption.TopDirectoryOnly;}

            fileNames = System.IO.Directory.GetFiles(path, "*.*", search);
            foreach (string name in fileNames)
            {
                //System.Diagnostics.Debug.WriteLine(name);
                if (!isIgnoreFolder(path,name))
                    files.Add(new System.IO.FileInfo(name));
            }
            return files;
        }

        private static bool isIgnoreFolder(string rootPath, string filePath)
        {
            string path = filePath.Remove(0, rootPath.Length+1);

            if (path.IndexOf(@"\") < 0)
                return false;
            path = path.Substring(0, path.LastIndexOf(@"\"));
            //return s_ignoreFolders.Contains(path);
            foreach (string s in Data.ignoreFolders)
            {
                if (path.IndexOf(s)> -1) 
                    return true;
            }
            return false;
        }

        public static void ProjectList(Dictionary<string, Project> the_Projects, DCT_Type enmProject)
        {
            switch (enmProject)
            { 
                case DCT_Type.Project : 
                    s_Projects = the_Projects;
                    break;

                case DCT_Type.Project_Common:
                    s_Projects_Common = the_Projects;
                    break;
                case DCT_Type.Project_TCommon:
                    s_Projects_TCommon = the_Projects;
                    break;
                case DCT_Type.Project_Gateway:
                    s_Projects_Gateway = the_Projects;
                    break;

                case DCT_Type.Reference :
                    s_References = the_Projects;
                    break;
                case DCT_Type.VBP :
                    s_VBPs = the_Projects;
                    processProjects();
                    break;
            }

            DataChanged(the_Projects, enmProject);

        }

        private static void processProjects()
        {
            s_AllReferences = new SortedDictionary<string, Reference>();
            s_Merged = new Dictionary<string, Project>();
            s_Orphan = new Dictionary<string, Project>();
            Dictionary<string, Project> _MergedProjects = new Dictionary<string, Project>();
            Dictionary<string, Project> _OrphanProjects = new Dictionary<string, Project>();
            int orphanCounter = 0;

            foreach (KeyValuePair<string, Project> kvp in Data.s_VBPs)
            {
                Project _merged = kvp.Value;
                bool orphan = false;

                string exename="";
                kvp.Value.Properties.TryGetValue("ExeName32", out exename);
                if (exename == null) exename = "";
                exename = exename.Replace(@"""", "").Trim();
                System.Diagnostics.Debug.WriteLine(exename);

                orphan = (!s_Projects.ContainsKey(exename) || (exename.Length == 0));


                _merged.VBP = _merged.Name;
                //if (_merged.ControlUsed == null)
                //    _merged.ControlUsed = new Dictionary<string, Project>();
                string tempVBP = _merged.Name;
                if (!orphan)
                {
                    Project bin = s_Projects[exename];
                    _merged = bin;
                    _merged.VBP = kvp.Value.VBP;
                    _merged.SourcePath = kvp.Value.SourcePath;
                    _merged.Properties = kvp.Value.Properties;
                    _merged.References = kvp.Value.References;
                    _merged.ControlUsed = kvp.Value.ControlUsed;
                    //_merged.BinPath = bin.BinPath;
                    //_merged.GUID = bin.GUID;
                    //_merged.Description = bin.Description;
                    //_merged.Version = bin.Version;
                    //_merged.EXEName = exename;
                    _MergedProjects.Add(exename, _merged);
                }
                else
                    _OrphanProjects.Add(string.Format("{0}_{1}",orphanCounter,_merged.Name) , _merged);


                if ((!Data.s_includeOrphans) && (orphan))
                    continue;

                //loop through vbp references
                foreach(KeyValuePair<string,Project> kvpRef in _merged.References)
                {
                    Project _pro = kvpRef.Value;
                    Reference _ref = new Reference();
                    //_pro.VBP = _merged.VBP;
                    _merged.ReferenceTree.Add(_pro.Name, _pro);

                    if (!s_AllReferences.ContainsKey(_pro.Name))
                    {
                        //add to Dictionary and add ref
                        _ref.GUID = _pro.GUID;
                        _ref.Project = _pro;
                        _ref.ReferecedBy.Add(_merged.Name, _merged);
                        s_AllReferences.Add(_pro.Name, _ref);
                        continue;
                    }
                    else
                    {
                        Reference ts = s_AllReferences[_pro.Name];
                        if(!ts.ReferecedBy.ContainsKey(_merged.Name))
                            s_AllReferences[_pro.Name].ReferecedBy.Add(_merged.Name, _merged);
                        //if(!ts.ReferecedBy[_merged.Name].GUID=="")
                        //    s_AllReferences[_pro.Name].ReferecedBy.Add(_merged.Name, _merged);
                    }

                    //_ref = s_AllReferences[_pro.Name];
                    //_ref.ReferecedBy.Add(_merged.Name, _merged);
                }

            }
            s_Merged = _MergedProjects;
            s_Orphan = _OrphanProjects;

            //processReferences();

        }

        private static void processReferences()
        {
        //
            //build list projects
            //foreach project, recursively add refs as projects and repeat
            foreach(Project prj in Data.s_Merged.Values)
            {
                System.Diagnostics.Debug.WriteLine(@"->" + prj.EXEName);

                foreach (Project refs in prj.ReferenceTree.Values)
                {
                    Project newPrj = null;
                    s_iDepth = 0;
                    System.Diagnostics.Debug.WriteLine(@"-->" + refs.EXEName);

                    if ((prj.EXEName) == refs.Name)
                    {//circular badness
                        newPrj = refs;
                    }
                    else
                    {
                        newPrj = buildRefs(refs);
                    }
                    if (newPrj != null)
                    {
                        refs.ReferenceTree[newPrj.EXEName] = newPrj;
                        System.Diagnostics.Debug.WriteLine(prj.EXEName + @"<--" + newPrj.EXEName);
                    }
                }

            }
        }

        private static Project buildRefs(Project prj)
        {
            if (!Data.s_Merged.ContainsKey(prj.EXEName))
                return null;

            Project prjx = Data.s_Merged[prj.EXEName];

            s_iDepth += 1;
            foreach (Project refs in prjx.ReferenceTree.Values)
            {
                //System.Diagnostics.Debug.WriteLine(refs.EXEName);

                Project newPrj = null;

                if ((prj.EXEName) == refs.Name)
                {//circular badness
                    newPrj = refs;
                }
                else
                {
                    newPrj = buildRefs(refs);
                }

                if (newPrj != null)
                {
                    refs.ReferenceTree[newPrj.EXEName] = newPrj;
                    System.Diagnostics.Debug.WriteLine(prjx.EXEName + @"<--" + newPrj.EXEName);
                }
            }

            s_iDepth -= 1;
            return prjx;
        }

        public static Project getReferenceFromLine(string referenceText,string startPath)
        {
            bool ok = true;
            Project project = new Project();
            string s1 = "";
            string s2 = "";

            try
            {
                if (referenceText.Contains(@"*\A"))
                {
                    ok = false;
                    project.Name = referenceText.Substring(referenceText.LastIndexOf(@"\")+1).Trim();
                    return project;
                }
                string[] s = referenceText.Split(new char[] {'#'});

                project.GUID = s[0].Substring(s[0].IndexOf("{"), s[0].Length - s[0].IndexOf("{")).Trim();

                if (s[2].Contains(";"))
                {
                    string[] sx = s[2].Split(new char[] { ';' });
                    s[2] = sx[0];
                    string[] sz = new string[5];
                    sz[0] = s[0];
                    sz[1] = s[1];
                    sz[2] = s[2];
                    sz[3] = sx[1];
                    sz[4] = sx[1];

                    s = sz;
                }

                project.Description = s[4].Trim();

                string path = "";
                string filename = s[3].Trim();

                if (s[3].IndexOf(@"\") > -1)
                {
                    path = s[3].Substring(0, s[3].LastIndexOf(@"\")).Trim();
                    filename = s[3].Remove(0, s[3].LastIndexOf(@"\") + 1).Trim();
                }

                string fullPath = tryResolveRelativePath(startPath, path).Trim();
                //fullPath = @"F:\SVN\App\v1.1\trunk\Client\Bin\Common";
                if (fullPath == @"F:\WINDOWS\system32")
                    fullPath = @"C:\WINDOWS\system32";
                System.IO.FileInfo fi = new System.IO.FileInfo(fullPath + @"\" + filename);
                if (fi.Exists)
                {
                    System.Diagnostics.FileVersionInfo f = System.Diagnostics.FileVersionInfo.GetVersionInfo(fullPath + @"\" + filename);
                    
                    //System.Diagnostics.Debug.WriteLine(f.FileDescription);
                    //System.Diagnostics.Debug.WriteLine(f.FileVersion);
                    //System.Diagnostics.Debug.WriteLine(f.InternalName);
                    //System.Diagnostics.Debug.WriteLine(f.OriginalFilename);
                    //System.Diagnostics.Debug.WriteLine(f.ProductName);
                    //System.Diagnostics.Debug.WriteLine(f.ProductVersion);
                    //System.Diagnostics.Debug.WriteLine(f.FileMajorPart);
                    //System.Diagnostics.Debug.WriteLine(f.FileMinorPart);
                    //System.Diagnostics.Debug.WriteLine(f.FileBuildPart);
                    //System.Diagnostics.Debug.WriteLine(f.FilePrivatePart);
                    //System.Diagnostics.Debug.WriteLine(f.CompanyName);
                    //System.Diagnostics.Debug.WriteLine(f.Comments);
                    project.GUID = Data.GetGuid(fullPath + @"\" + filename);
                    project.Version = f.ProductVersion;
                    project.SourcePath = fullPath;
                    project.EXEName = filename;
                    project.Name = filename;
                }
                else
                {
                    bool found = false;
                    Project x=null;
                    //Dictionary<string, Project>.ValueCollection vc = s_Projects.Values;
                    //vc.ElementAt(
                    foreach (KeyValuePair<string, Project> kvp in s_Projects)
                    {
                        if (kvp.Key == filename)
                        {
                            x = kvp.Value;
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        foreach (KeyValuePair<string, Project> kvp in s_Projects_Common)
                        {
                            if (kvp.Key == filename)
                            {
                                x = kvp.Value;
                                found = true;
                                break;
                            }
                        }
                    }
                    if (!found)
                    {
                        foreach (KeyValuePair<string, Project> kvp in s_Projects_TCommon)
                        {
                            if (kvp.Key == filename)
                            {
                                x = kvp.Value;
                                found = true;
                                break;
                            }
                        }
                    }
                    if (!found)
                    {
                        foreach (KeyValuePair<string, Project> kvp in s_Projects_Gateway)
                        {
                            if (kvp.Key == filename)
                            {
                                x = kvp.Value;
                                found = true;
                                break;
                            }
                        }
                    }


                    if (found)
                    {
                        //found = false;
                        //System.Diagnostics.FileVersionInfo fv = System.Diagnostics.FileVersionInfo.GetVersionInfo(x.BinPath + @"\" + filename);
                        //System.IO.FileInfo fiv = new System.IO.FileInfo(x.BinPath + @"\" + filename);
                        //if (fiv.Exists)
                        //{
                        //project.Version = x.Version;// fv.ProductVersion;
                        //project.SourcePath = x.BinPath;
                        //found = true;
                        //}
                        project = x;
                    }
                    if(!found)
                    {
                        project.Version = string.Concat(s[1], ".", s[2]);
                        project.SourcePath = path;
                        project.EXEName = filename; 
                        project.Name = filename;
                        //project.SourcePath = path;
                    }
                }
                project.REF = true;

            }
            catch (Exception)
            {

                throw;
            }

            return project;
        }

        private static string tryResolveRelativePath(string startPath,string searchPath)
        {
            if (searchPath.Length == 0)
                return startPath;
            if (searchPath.Substring(1,1).ToString() == @":")
                return searchPath;
            System.IO.Directory.SetCurrentDirectory(startPath);
            string test = System.IO.Path.GetFullPath(@"\.." + searchPath);
            return test;
        }




        //public string SerializeDict()
        //{


        //}

        

        //public void ReadXml(System.Xml.XmlReader reader)

        //{

        //    XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));

        //    XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));

 

        //    bool wasEmpty = reader.IsEmptyElement;

        //    reader.Read();

 

        //    if (wasEmpty)

        //        return;

 

        //    while (reader.NodeType != System.Xml.XmlNodeType.EndElement)

        //    {

        //        reader.ReadStartElement("item");

 

        //        reader.ReadStartElement("key");

        //        TKey key = (TKey)keySerializer.Deserialize(reader);

        //        reader.ReadEndElement();

 

        //        reader.ReadStartElement("value");

        //        TValue value = (TValue)valueSerializer.Deserialize(reader);

        //        reader.ReadEndElement();

 

        //        this.Add(key, value);

 

        //        reader.ReadEndElement();

        //        reader.MoveToContent();

        //    }

        //    reader.ReadEndElement();

        //}

        //public void WriteXml(System.Xml.XmlWriter writer)

        //{

        //    XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));

        //    XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));

 

        //    foreach (TKey key in this.Keys)

        //    {

        //        writer.WriteStartElement("item");

 

        //        writer.WriteStartElement("key");

        //        keySerializer.Serialize(writer, key);

        //        writer.WriteEndElement();

 

        //        writer.WriteStartElement("value");

        //        TValue value = this[key];

        //        valueSerializer.Serialize(writer, value);

        //        writer.WriteEndElement();

 

        //        writer.WriteEndElement();

        //    }

        //}


    }


    public enum DCT_Type
    { 
        Project,
        VBP,
        Reference,
        Project_Common,
        Project_TCommon,
        Project_Gateway
    }




}



/*
 * scan bin folder
 *  get list of dll, tlb, ocx, exe
 * scan src root folder
 *  get list of vbp
 * link/compare vbp/bins
 * process vbp
 *  check refs
 *      paths
 *      versions
 *      guids
 *  check guid
 *  
 * 
 * 
*/
