﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectBuilder
{
    class File
    {
        string sGUID;
        string sName;
        string sDescription;
        string sPath;
        string sVersion;

        public string GUID
        {
            get { return sGUID; }
            set { sGUID = value; }
        }

        public string Name
        {
            get { return sName; }
            set { sName = value; }
        }

        public string Description
        {
            get { return sDescription; }
            set { sDescription = value; }
        }

        public string Path
        {
            get { return sPath; }
            set { sPath = value; }
        }

        public string Version
        {
            get { return sVersion; }
            set { sVersion = value; }
        }

        public File(string the_name)
        {
            this.sName = the_name;
        }

    }
}
