﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace ProjectBuilder
{
    public class Project
    {
        string _Name;
        string _GUID;
        string _srcPath;
        string _binPath;
        string _Version;
        string _EXEName;
        string _VBP;
        string _Description;
        bool _REF;
        Dictionary<string, string> _Properties;
        Dictionary<string, Project> _References;
        Dictionary<string, Project> _ControlUsed;
        Dictionary<string, Project> _ReferenceTree = new Dictionary<string, Project>();
        DCT_Type _projectType;

        public DCT_Type ProjectType
        {
            get { return _projectType; }
            set { _projectType = value; }
        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string GUID
        {
            get { return _GUID; }
            set { _GUID = value; }
        }

        public string SourcePath
        {
            get { return _srcPath; }
            set { _srcPath = value; }
        }

        public string BinPath
        {
            get { return _binPath; }
            set { _binPath = value; }
        }

        public string Version
        {
            get { return _Version; }
            set { _Version = value; }
        }

        public string EXEName
        {
            get { return _EXEName; }
            set { _EXEName = value; }
        }

        public string VBP
        {
            get { return _VBP; }
            set { _VBP = value; }
        }
        
        public bool REF
        {
            get { return _REF; }
            set { _REF = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        
        public Dictionary<string, string> Properties
        {
            get { return _Properties; }
            set { _Properties = value; }
        }
        
        public Dictionary<string, Project> References
        {
            get { return _References; }
            set { _References = value; }
        }

        public Dictionary<string, Project> ControlUsed
        {
            get { return _ControlUsed; }
            set { _ControlUsed = value; }
        }

        public Dictionary<string, Project> ReferenceTree
        {
            get { return _ReferenceTree; }
            set { _ReferenceTree = value; }
        }

    }

    public class Reference
    {
        Project _Project=new Project();
        string _GUID;
        Dictionary<string, Project> _ReferecedBy = new Dictionary<string, Project>();
        
        public Project Project
        {
            get { return _Project; }
            set { _Project = value; }
        }

        public string GUID
        {
            get { return _GUID; }
            set { _GUID = value; }
        }

        public Dictionary<string, Project> ReferecedBy
        {
            get { return _ReferecedBy; }
            set { _ReferecedBy = value; }
        }

    }

}
