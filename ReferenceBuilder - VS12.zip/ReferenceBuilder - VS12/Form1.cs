﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ProjectBuilder
{
    public partial class Form1 : Form
    {
        //public event UpdatedEventHandler ProjectsUpdated;

        public Form1()
        {
            InitializeComponent();
            txtRootPath.Text = Data.s_RootPath;
        }

        private void cmdStart_Click(object sender, EventArgs e)
        {
            
            Data.s_RootPath = txtRootPath.Text;
            Branch b = new Branch();
            Data.DataChanged += this.updateProjects;
            lvwProjects.Items.Clear();
        
            b.Process();
            Data.exportToXML();
            Data.exportToXML2();
            Form2 frm = new Form2();
            frm.Show();



        }
        private void dispData()
        {
            StringBuilder sb = new StringBuilder();
            string nodes = "node [shape=ellipse];";
            string sValue = "";
            string sValue2 = "";
            string sNode = "node";
            int counter = 0;

            foreach (KeyValuePair<string, Reference> kvp in Data.AllReferences)
            {
                sValue = "'" + kvp.Value.Project.EXEName + "'";
                //nodes = nodes + "{node [label=" + sValue + "]" + sNode + counter + ";";
                nodes += sValue + ";";

                if (kvp.Value.ReferecedBy.Count == 0)
                {
                    sb.AppendLine(sValue);
                }
                else
                {

                    foreach (KeyValuePair<string, Project> _prj in kvp.Value.ReferecedBy)
                    {
                        sValue2 = "'" + _prj.Value.Name + "'";
                        sb.AppendLine(sValue + " -- " + sValue2 + ";");
                    }

                }

            }
            sb.Insert(0, nodes );
            sb.Insert(0, "graph ER {");
            sb.AppendLine("}");

            StreamWriter sw = new StreamWriter(@"C:\RefsGraph.txt");
            sw.Write(sb.ToString());
            sw.Close(); 
            //TextWriter tx = File.CreateText("");
            //StringWriter sw = new StringWriter(sb);
            //sw.Write(sb.ToString());
            //sw.Close();
            

            
            //foreach (KeyValuePair<string, Reference> kvp in Data.AllReferences)
            //{
            //    sValue = kvp.Value.Project.EXEName;
            //    nodes = nodes + "{node [label=" + sValue + "]" + sNode + counter + ";";

            //    if(kvp.Value.ReferecedBy.Count = 0)
            //    {
            //        sb.AppendLine(sValue);
            //    }
            //    else
            //    {

            //        foreach (KeyValuePair<string, Project> _prj in kvp.Value.ReferecedBy)
            //        {
            //            sValue2 = _prj.Value.Name;
            //            sb.AppendLine(sValue + " -- " + sValue2);
            //        }
                    
            //    }

            //}
        }


        private void updateProjects(Dictionary<string, Project> the_Projects, DCT_Type enmProject)
        {
            switch (enmProject)
            {
                case DCT_Type.Project:
                    updateProjects(the_Projects);
                    return;
                case DCT_Type.Reference:
                    updateReferences(the_Projects);
                    return;
            }
            
        }

        private void updateProjects(Dictionary<string, Project> the_Projects)
        { 
            if (lvwProjects.Columns.Count == 0)
            {
                lvwProjects.Columns.Add("Name");
                lvwProjects.Columns.Add("Version");
                lvwProjects.Columns.Add("EXEName");
                lvwProjects.Columns.Add("GUID");
                lvwProjects.Columns.Add("Path");
            }
            foreach (KeyValuePair<string, Project> prj in the_Projects)
            {
                String[] val = { prj.Value.Name, prj.Value.Version, prj.Value.EXEName, prj.Value.GUID, prj.Value.BinPath };
                ListViewItem lvwi = new ListViewItem(val);
                lvwProjects.Items.Add(lvwi);

            }
            lvwProjects.Refresh();
        }

        private void updateReferences(Dictionary<string, Project> the_References)
        { 
        //
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dispData();

            List<string> keys = new List<string>(Data.AllReferences.Keys);
            keys.Sort();
            //s = Data.AllReferences.Values();

            foreach (string st in keys)
            {
                if (Data.AllReferences.ContainsKey(st))
                {
                    Reference val = Data.AllReferences[st];
                    System.Diagnostics.Debug.WriteLine(val.Project.Name);
                    System.Diagnostics.Debug.WriteLine(val.GUID);
                    System.Diagnostics.Debug.WriteLine(val.ReferecedBy);

                }


            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            StringBuilder sb = new StringBuilder();
            string sValue = "";
            string sValue2 = "";
            string sNode = "node";
            int counter = 0;

            foreach (KeyValuePair<string, Reference> kvp in Data.AllReferences)
            {
                sValue = "'" + kvp.Value.Project.EXEName + "'";

                if (kvp.Value.ReferecedBy.Count == 0)
                {
                    sb.AppendLine(sValue);
                }
                else
                {
                    foreach (KeyValuePair<string, Project> _prj in kvp.Value.Project.References)
                    {
                        sValue2 = "'" + _prj.Value.Name + "'";
                        sb.AppendLine(sValue + " -- " + sValue2 + ";");
                    }

                }

            }

            StreamWriter sw = new StreamWriter(@"C:\Refs.txt");
            sw.Write(sb.ToString());
            sw.Close(); 

        }

    }
}
