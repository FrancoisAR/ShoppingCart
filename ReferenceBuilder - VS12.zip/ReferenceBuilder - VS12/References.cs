﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectBuilder
{
    public class References
    {
        string _Name;
        string _GUID;
        string _Path;
        string _Version;
        string _EXEName;
        string _VBP;
        bool _REF;
        
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string GUID
        {
            get { return _GUID; }
            set { _GUID = value; }
        }

        public string Path
        {
            get { return _Path; }
            set { _Path = value; }
        }

        public string Version
        {
            get { return _Version; }
            set { _Version = value; }
        }

        public string EXEName
        {
            get { return _EXEName; }
            set { _EXEName = value; }
        }

        public string VBP
        {
            get { return _VBP; }
            set { _VBP = value; }
        }
        
        public bool REF
        {
            get { return _REF; }
            set { _REF = value; }
        }
    }
}
