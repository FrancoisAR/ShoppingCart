﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace ProjectBuilder
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            populateReferences();
        }
        private void populateReferences()
        { 

            XmlDocument xmlDoc = new System.Xml.XmlDocument();
            //xmlDoc.LoadXml("");
            XmlNode root = xmlDoc.CreateNode("element", "References", "");
            xmlDoc.PrependChild(root);

            foreach (KeyValuePair<string, Reference> kvp in Data.AllReferences)
            {
                XmlNode project = xmlDoc.CreateNode("element", "binary", "");
                XmlAttribute xmlatt = null;
                xmlatt = xmlDoc.CreateAttribute("name"); //.Value=kvp.Value.Project.EXEName;
                xmlatt.Value = kvp.Value.Project.EXEName;
                project.Attributes.Append (xmlatt);

                TreeNode tnReference=new TreeNode(kvp.Value.Project.EXEName);
                
                foreach (KeyValuePair<string, Project> _prj in kvp.Value.ReferecedBy)
                {
                    XmlNode refs = xmlDoc.CreateNode("element", "reference", "");

                    xmlatt = xmlDoc.CreateAttribute("name");
                    refs.Attributes.Append(xmlatt).Value = _prj.Value.Name;
                    xmlatt = xmlDoc.CreateAttribute("GUID");
                    refs.Attributes.Append(xmlatt).Value = _prj.Value.GUID;
                    xmlatt = xmlDoc.CreateAttribute("Version");
                    refs.Attributes.Append(xmlatt).Value = _prj.Value.Version;
                    xmlatt = xmlDoc.CreateAttribute("Path");
                    refs.Attributes.Append(xmlatt).Value = _prj.Value.BinPath;

                    TreeNode tn = new TreeNode(_prj.Value.Name);
                    tn.Nodes.Add("GUID      : " + _prj.Value.GUID);
                    tn.Nodes.Add("Version   : " + _prj.Value.Version);
                    tn.Nodes.Add("File Path : " + _prj.Value.BinPath);

                    tnReference.Nodes.Add(tn);
                    
                    project.AppendChild(refs);
                }
                treeView1.Nodes.Add(tnReference);

                root.AppendChild(project);
            }
            treeView1.Sort();
            xmlDoc.Save(@"C:\Temp\ProjectBuilder.xml");
        }

    }
}
