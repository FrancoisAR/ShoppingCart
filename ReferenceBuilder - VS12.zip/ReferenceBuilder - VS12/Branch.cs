﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Diagnostics;

namespace ProjectBuilder
{
    class Branch
    {
        public Branch()
        { }

        public void Process()
        {
            getSettings();

            ScanBins(string.Format(Data.s_ProjectPath, "Trunk", @"bin\Common"), DCT_Type.Project_Common, false);
            ScanBins(string.Format(Data.s_ProjectPath, "Trunk", @"bin\App Common"), DCT_Type.Project_TCommon, false);
            ScanBins(string.Format(Data.s_ProjectPath, "Trunk", @"bin\Gateway"), DCT_Type.Project_Gateway, true);
            ScanBins(string.Format(Data.s_ProjectPath, "Trunk", "bin"), DCT_Type.Project, false);

            Data.bin_SearchSubFolders = true;
            ScanProjects();
            
        }

        private void getSettings()
        {
            string line = "";
            String strAppDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            String strFullPath = Path.Combine(strAppDir, "ignorefolders.txt");
            strFullPath =  strFullPath.Remove(0, 6);

            StreamReader file = new StreamReader(strFullPath);
            System.Collections.ArrayList aTemp=new System.Collections.ArrayList();
            
            while ((line = file.ReadLine()) != null)
            {
                aTemp.Add(line);
            }
            file.Close();
            Data.ignoreFolders = aTemp;
        }


        private void ScanBins(string sBranch, DCT_Type projectType, bool SearchSubFolders)
        {
            Data.bin_SearchSubFolders = SearchSubFolders;
            //string sBranch = string.Format(Data.s_ProjectPath, "Trunk","bin");
            IEnumerable<System.IO.FileInfo> fileList = Data.GetFiles(sBranch);

            var searchFiles =
                from file in fileList
                orderby file.FullName ascending 
                where file.Extension == ".dll" || file.Extension == ".ocx" || file.Extension == ".exe" || file.Extension == ".tlb"
                select new
                {
                    fullname = file.FullName,
                    name = file.Name,
                    path = file.Directory
                };

            Dictionary<string, Project> dctTemp = new Dictionary<string, Project>();
            foreach (var v in searchFiles)
            {
                FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(v.fullname);
                string sGUID = Data.GetGuid(v.fullname);
                string output = string.Format(
@"
File Name: {0}
Path:      {1}
Version:   {2}
GUID:      {3}", v.name, v.path, fvi.FileVersion, sGUID);

                Debug.WriteLine(output);
                Project prj = new Project();
                prj.Name=v.name;
                prj.Version = fvi.FileVersion;
                prj.EXEName =v.name;
                prj.GUID = sGUID;
                prj.BinPath =v.path.ToString();
                prj.ProjectType = projectType;
                dctTemp.Add(v.name,prj);
            }

            Data.ProjectList(dctTemp, projectType); //DCT_Type.Project);
            Data.bin_SearchSubFolders = false;
        }

        private void ScanProjects()
        {
            string sBranch = string.Format(Data.s_ProjectPath, "Trunk", "src");
            IEnumerable<System.IO.FileInfo> fileList = Data.GetFiles(sBranch);

            var searchFiles =
            from file in fileList
            orderby file.FullName ascending 
            where file.Extension == ".vbp"
            select new
            {
                fullname = file.FullName,
                name = file.Name,
                path = file.Directory
            };

            Dictionary<string, Project> dctTemp = new Dictionary<string, Project>();
            
            foreach (var v in searchFiles)
            {
                Project prjVBP = new Project();
                Project prj = null;
                Dictionary<string, string> dctVBP = new Dictionary<string, string>();
                Dictionary<string, Project> dctReferences = new Dictionary<string, Project>();
                Dictionary<string, Project> dctControlUsed = new Dictionary<string, Project>();
                string line;
                string s1 = "";
                string s2 = "";
                string appDir = "";

                int lReferenceCount = 0;
                int lClassCount = 0;
                int lFormCount = 0;
                int lModuleCount = 0;
                int lObjectCount = 0;
                int lUserControlCount = 0;
                System.Diagnostics.Debug.WriteLine(v.name);
                StreamReader file =
                new StreamReader(v.fullname);
                while ((line = file.ReadLine()) != null)
                {
                    //Debug.WriteLine(line);
                    int i = line.IndexOf("=", 0);
                    if (i >= 0)
                    {
                        s1 = line.Substring(0, i);
                        s2 = line.Substring(i + 1);
                    }
                    else
                    {
                        s1 = line;
                        s2 = "";
                    }

                    switch (s1)
                    {
                        case "Reference":
                            lReferenceCount += 1;

                            appDir = System.IO.Directory.GetCurrentDirectory();
                            prj = Data.getReferenceFromLine(s2, v.path.ToString());
                            System.IO.Directory.SetCurrentDirectory(appDir);
                            dctReferences.Add(prj.Name, prj);
                            s1 = string.Concat(s1, lReferenceCount.ToString());
                            break;
                        case "Class":
                            lClassCount += 1;
                            s1 = string.Concat(s1, lClassCount.ToString());
                            break;
                        case "Form":
                            lFormCount += 1;
                            s1 = string.Concat(s1, lFormCount.ToString());
                            break;
                        case "Module":
                            lModuleCount += 1;
                            s1 = string.Concat(s1, lModuleCount.ToString());
                            break;
                        case "Object":
                            lObjectCount += 1;
                            
                            appDir = System.IO.Directory.GetCurrentDirectory();
                            prj = Data.getReferenceFromLine(s2, v.path.ToString());
                            System.IO.Directory.SetCurrentDirectory(appDir);
                            dctControlUsed.Add(prj.Name, prj);

                            s1 = string.Concat(s1, lObjectCount.ToString());
                            break;
                        case "UserControl":
                            lUserControlCount += 1;
                            s1 = string.Concat(s1, lUserControlCount.ToString());
                            break;
                        default:
                            break;
                    }

                    if(s2!=string.Empty)
                        dctVBP.Add(s1, s2);
                }
                file.Close();

                prjVBP.References = dctReferences;
                prjVBP.ControlUsed = dctControlUsed;
                prjVBP.Name = v.name;
                prjVBP.SourcePath = v.path.ToString();
                prjVBP.Properties = dctVBP;
                
                dctTemp.Add(v.name, prjVBP);

//                string output = string.Format(
//@"
//File Name: {0}
//Path:      {1}", v.name, v.path);

//                Debug.WriteLine(output);

            }
            Data.ProjectList(dctTemp, DCT_Type.VBP);

        }



    }



}
